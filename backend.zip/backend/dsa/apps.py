from django.apps import AppConfig


class DsaConfig(AppConfig):
    name = 'dsa'
