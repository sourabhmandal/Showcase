from django.contrib import admin
from .models import Dsa
# Register your models here.
admin.site.register(Dsa)
