from django.contrib import admin
from .models import Courses

# Register your models here.
admin.site.register(Courses)
