from django.apps import AppConfig


class HobbiesConfig(AppConfig):
    name = 'Hobbies'
