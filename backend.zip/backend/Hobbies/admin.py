from django.contrib import admin
from .models import Hobbies

# Register your models here.
admin.site.register(Hobbies)
