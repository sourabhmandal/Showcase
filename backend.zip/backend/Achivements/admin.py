from django.contrib import admin
from .models import Achivements
# Register your models here.
admin.site.register(Achivements)
