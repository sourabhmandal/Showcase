from django.apps import AppConfig


class AchivementsConfig(AppConfig):
    name = 'Achivements'
