from django.apps import AppConfig


class SkillConfig(AppConfig):
    name = 'Skill'
